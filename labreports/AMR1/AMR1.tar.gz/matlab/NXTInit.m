function NXTInit
    global error
    error = [0 0];