function log = ReadLogFile(name)

log = load(name);