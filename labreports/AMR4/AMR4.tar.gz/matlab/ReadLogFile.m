function log = ReadLogFile(name)

log = load(name);
% 2: type 3:Dx 4:Dy
%  
% 
